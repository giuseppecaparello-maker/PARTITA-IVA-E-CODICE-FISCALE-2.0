import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export interface CompanyInfo {
  name: string;
  vatNumber: string;
  taxCode: string;
  headquarters?: string;
  description?: string;
  sourceUrls?: string[];
}

export async function searchCompany(query: string): Promise<CompanyInfo> {
  // Aggiungi un piccolo ritardo per evitare limiti di frequenza durante l'elaborazione batch
  await new Promise(resolve => setTimeout(resolve, 500));
  
  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Trova le informazioni legali (Partita IVA e Codice Fiscale) per l'azienda: ${query}. 
    Se l'azienda ha sede in Italia, fornisci i dati ufficiali. 
    Se non trovi i dati esatti, prova a cercarli sul sito ufficiale o registri pubblici.`,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          name: { type: Type.STRING, description: "Nome ufficiale dell'azienda" },
          vatNumber: { type: Type.STRING, description: "Partita IVA (11 cifre)" },
          taxCode: { type: Type.STRING, description: "Codice Fiscale" },
          headquarters: { type: Type.STRING, description: "Sede legale" },
          description: { type: Type.STRING, description: "Breve descrizione dell'attività" },
        },
        required: ["name", "vatNumber", "taxCode"],
      },
    },
  });

  const text = response.text || "{}";
  const data = JSON.parse(text);
  
  const sourceUrls = response.candidates?.[0]?.groundingMetadata?.groundingChunks
    ?.map(chunk => chunk.web?.uri)
    .filter((uri): uri is string => !!uri) || [];

  return {
    ...data,
    sourceUrls,
  };
}
