import React, { useState, useRef } from 'react';
import { Search, Building2, ExternalLink, Loader2, Info, CheckCircle2, AlertCircle, Upload, Download, FileText, X, Play, Pause, RotateCcw } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { searchCompany, CompanyInfo } from './services/geminiService';
import Papa from 'papaparse';

type Mode = 'single' | 'batch';

interface BatchItem {
  query: string;
  status: 'pending' | 'processing' | 'completed' | 'error';
  result?: CompanyInfo;
  error?: string;
}

export default function App() {
  const [mode, setMode] = useState<Mode>('single');
  
  // Single Mode State
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<CompanyInfo | null>(null);
  const [error, setError] = useState<string | null>(null);

  // Batch Mode State
  const [batchItems, setBatchItems] = useState<BatchItem[]>([]);
  const [isProcessingBatch, setIsProcessingBatch] = useState(false);
  const [filterLocation, setFilterLocation] = useState('');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const filteredBatchItems = batchItems.filter(item => {
    if (!filterLocation.trim()) return true;
    if (!item.result?.headquarters) return false;
    return item.result.headquarters.toLowerCase().includes(filterLocation.toLowerCase());
  });

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setLoading(true);
    setError(null);
    setResult(null);

    try {
      const data = await searchCompany(query);
      setResult(data);
    } catch (err) {
      console.error(err);
      setError("Si è verificato un errore durante la ricerca. Riprova tra poco.");
    } finally {
      setLoading(false);
    }
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      complete: (results) => {
        const names = results.data
          .flat()
          .map((n: any) => String(n).trim())
          .filter(n => n.length > 0);
        
        setBatchItems(names.map(name => ({ query: name, status: 'pending' })));
      },
      header: false,
      skipEmptyLines: true
    });
  };

  const processBatch = async () => {
    if (isProcessingBatch) return;
    setIsProcessingBatch(true);

    const itemsToProcess = [...batchItems];
    
    for (let i = 0; i < itemsToProcess.length; i++) {
      if (itemsToProcess[i].status === 'completed') continue;

      setBatchItems(prev => prev.map((item, idx) => 
        idx === i ? { ...item, status: 'processing' } : item
      ));

      try {
        const data = await searchCompany(itemsToProcess[i].query);
        setBatchItems(prev => prev.map((item, idx) => 
          idx === i ? { ...item, status: 'completed', result: data } : item
        ));
      } catch (err) {
        setBatchItems(prev => prev.map((item, idx) => 
          idx === i ? { ...item, status: 'error', error: "Errore" } : item
        ));
      }
    }

    setIsProcessingBatch(false);
  };

  const downloadCSV = () => {
    const itemsToExport = filterLocation.trim() ? filteredBatchItems : batchItems;
    const data = itemsToExport.map(item => ({
      "Azienda Ricercata": item.query,
      "Nome Ufficiale": item.result?.name || "",
      "Partita IVA": item.result?.vatNumber || "",
      "Codice Fiscale": item.result?.taxCode || "",
      "Sede": item.result?.headquarters || "",
      "Stato": item.status
    }));

    const csv = Papa.unparse(data);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    const url = URL.createObjectURL(blob);
    link.setAttribute("href", url);
    link.setAttribute("download", `risultati_aziende_${new Date().getTime()}.csv`);
    link.style.visibility = 'hidden';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  const clearBatch = () => {
    setBatchItems([]);
    setIsProcessingBatch(false);
    if (fileInputRef.current) fileInputRef.current.value = '';
  };

  return (
    <div className="min-h-screen flex flex-col items-center p-4 md:p-8 bg-stone-50">
      <header className="w-full max-w-4xl mb-12 text-center">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="inline-flex items-center justify-center p-2 bg-stone-200 rounded-full mb-4"
        >
          <Building2 className="w-5 h-5 text-stone-600 mr-2" />
          <span className="text-xs font-mono uppercase tracking-widest text-stone-600">Registro Imprese AI</span>
        </motion.div>
        <h1 className="text-4xl md:text-5xl font-medium tracking-tight mb-4">
          Trova Dati Aziendali
        </h1>
        
        <div className="flex flex-col md:flex-row justify-center items-center gap-4 mt-8">
          <div className="p-1 bg-stone-200 rounded-xl flex">
            <button
              onClick={() => setMode('single')}
              className={`px-6 py-2 rounded-lg text-sm font-medium transition-all ${mode === 'single' ? 'bg-white shadow-sm text-stone-900' : 'text-stone-500 hover:text-stone-700'}`}
            >
              Ricerca Singola
            </button>
            <button
              onClick={() => setMode('batch')}
              className={`px-6 py-2 rounded-lg text-sm font-medium transition-all ${mode === 'batch' ? 'bg-white shadow-sm text-stone-900' : 'text-stone-500 hover:text-stone-700'}`}
            >
              Elaborazione Batch
            </button>
          </div>
          
          <button
            onClick={() => {
              const sharedUrl = (process.env as any).SHARED_APP_URL;
              const appUrl = sharedUrl || (process.env as any).APP_URL || window.location.origin;
              navigator.clipboard.writeText(appUrl);
              alert("Link PUBBLICO copiato! Invia questo link ai tuoi colleghi.\n\nNota: Assicurati di aver cliccato sul tasto 'Share' in alto a destra in AI Studio per abilitare l'accesso esterno.");
            }}
            className="flex items-center px-4 py-2 bg-stone-900 text-white rounded-xl text-xs font-medium hover:bg-stone-800 transition-all shadow-md"
          >
            <ExternalLink className="w-3.5 h-3.5 mr-2" />
            Condividi con l'ufficio
          </button>
        </div>
      </header>

      <main className="w-full max-w-4xl">
        {mode === 'single' ? (
          <div className="max-w-2xl mx-auto">
            <form onSubmit={handleSearch} className="relative mb-8">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Es: Google Italy, Ferrari S.p.A..."
                className="w-full h-16 pl-14 pr-32 bg-white border border-stone-300 rounded-2xl shadow-sm focus:outline-none focus:ring-2 focus:ring-stone-400 transition-all text-lg"
              />
              <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-stone-400 w-6 h-6" />
              <button
                type="submit"
                disabled={loading || !query.trim()}
                className="absolute right-3 top-1/2 -translate-y-1/2 h-10 px-6 bg-stone-900 text-white rounded-xl font-medium hover:bg-stone-800 disabled:opacity-50 disabled:cursor-not-allowed transition-colors flex items-center"
              >
                {loading ? <Loader2 className="w-4 h-4 animate-spin" /> : 'Cerca'}
              </button>
            </form>

            <AnimatePresence mode="wait">
              {loading && (
                <motion.div
                  key="loading"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="flex flex-col items-center justify-center py-20 space-y-4"
                >
                  <Loader2 className="w-10 h-10 text-stone-400 animate-spin" />
                  <p className="text-stone-500 font-mono text-xs uppercase tracking-widest animate-pulse">
                    Ricerca in corso nei registri pubblici...
                  </p>
                </motion.div>
              )}

              {error && (
                <motion.div
                  key="error"
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  className="p-4 bg-red-50 border border-red-100 rounded-2xl flex items-start space-x-3"
                >
                  <AlertCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
                  <p className="text-red-700 text-sm">{error}</p>
                </motion.div>
              )}

              {result && (
                <motion.div
                  key="result"
                  initial={{ opacity: 0, y: 20 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="bg-white border border-stone-200 rounded-3xl shadow-xl overflow-hidden"
                >
                  <div className="p-6 md:p-8 border-b border-stone-100">
                    <div className="flex justify-between items-start mb-6">
                      <div>
                        <h2 className="text-2xl font-semibold mb-1">{result.name}</h2>
                        <p className="text-stone-500 text-sm flex items-center">
                          <CheckCircle2 className="w-4 h-4 text-emerald-500 mr-1.5" />
                          Dati verificati tramite ricerca AI
                        </p>
                      </div>
                      <div className="bg-stone-100 p-3 rounded-2xl">
                        <Building2 className="w-6 h-6 text-stone-600" />
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono uppercase tracking-widest text-stone-400">Partita IVA</label>
                        <div className="text-xl font-mono tracking-tight bg-stone-50 p-3 rounded-xl border border-stone-100">
                          {result.vatNumber}
                        </div>
                      </div>
                      <div className="space-y-1">
                        <label className="text-[10px] font-mono uppercase tracking-widest text-stone-400">Codice Fiscale</label>
                        <div className="text-xl font-mono tracking-tight bg-stone-50 p-3 rounded-xl border border-stone-100">
                          {result.taxCode}
                        </div>
                      </div>
                    </div>
                  </div>

                  <div className="p-6 md:p-8 bg-stone-50/50 space-y-6">
                    {result.headquarters && (
                      <div>
                        <h3 className="text-xs font-mono uppercase tracking-widest text-stone-400 mb-2">Sede Legale</h3>
                        <p className="text-stone-700 leading-relaxed">{result.headquarters}</p>
                      </div>
                    )}

                    {result.description && (
                      <div>
                        <h3 className="text-xs font-mono uppercase tracking-widest text-stone-400 mb-2">Descrizione</h3>
                        <p className="text-stone-600 text-sm leading-relaxed">{result.description}</p>
                      </div>
                    )}

                    {result.sourceUrls && result.sourceUrls.length > 0 && (
                      <div className="pt-4 border-t border-stone-200">
                        <h3 className="text-[10px] font-mono uppercase tracking-widest text-stone-400 mb-3 flex items-center">
                          <Info className="w-3 h-3 mr-1.5" /> Fonti consultate
                        </h3>
                        <div className="flex flex-wrap gap-2">
                          {result.sourceUrls.map((url, i) => (
                            <a
                              key={i}
                              href={url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="inline-flex items-center px-3 py-1.5 bg-white border border-stone-200 rounded-lg text-xs text-stone-600 hover:bg-stone-100 transition-colors"
                            >
                              {new URL(url).hostname}
                              <ExternalLink className="w-3 h-3 ml-1.5 opacity-50" />
                            </a>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="md:col-span-1 bg-white p-6 rounded-3xl border border-stone-200 shadow-sm space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-semibold flex items-center">
                    <Upload className="w-5 h-5 mr-2 text-stone-500" /> Inserimento Dati
                  </h3>
                  
                  <div className="space-y-2">
                    <label className="text-[10px] font-mono uppercase tracking-widest text-stone-400">Inserimento Manuale</label>
                    <textarea
                      placeholder="Inserisci un nome per riga..."
                      className="w-full h-32 p-3 bg-stone-50 border border-stone-200 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-stone-400 transition-all resize-none"
                      onChange={(e) => {
                        const names = e.target.value.split('\n').map(n => n.trim()).filter(n => n.length > 0);
                        if (names.length > 0) {
                          setBatchItems(names.map(name => ({ query: name, status: 'pending' })));
                        } else {
                          setBatchItems([]);
                        }
                      }}
                    />
                  </div>

                  <div className="relative">
                    <div className="absolute inset-0 flex items-center" aria-hidden="true">
                      <div className="w-full border-t border-stone-100"></div>
                    </div>
                    <div className="relative flex justify-center text-xs uppercase tracking-widest font-mono">
                      <span className="bg-white px-2 text-stone-300">Oppure</span>
                    </div>
                  </div>

                  <div>
                    <input
                      type="file"
                      ref={fileInputRef}
                      onChange={handleFileUpload}
                      accept=".csv,.txt"
                      className="hidden"
                    />
                    <button
                      onClick={() => fileInputRef.current?.click()}
                      className="w-full py-3 border-2 border-dashed border-stone-300 rounded-2xl text-stone-500 hover:border-stone-400 hover:bg-stone-50 transition-all flex flex-col items-center justify-center space-y-1"
                    >
                      <FileText className="w-5 h-5 opacity-50" />
                      <span className="text-[10px] font-medium uppercase tracking-widest">Carica CSV</span>
                    </button>
                  </div>
                </div>

                {batchItems.length > 0 && (
                  <div className="pt-6 border-t border-stone-100 space-y-3">
                    <div className="flex justify-between items-center text-xs font-mono uppercase tracking-widest text-stone-400">
                      <span>Totale Aziende</span>
                      <span className="text-stone-900 font-bold">{batchItems.length}</span>
                    </div>
                    <div className="flex justify-between items-center text-xs font-mono uppercase tracking-widest text-stone-400">
                      <span>Completate</span>
                      <span className="text-emerald-600 font-bold">
                        {batchItems.filter(i => i.status === 'completed').length}
                      </span>
                    </div>
                    
                    <div className="pt-4 flex gap-2">
                      <button
                        onClick={processBatch}
                        disabled={isProcessingBatch || batchItems.every(i => i.status === 'completed')}
                        className="flex-1 py-3 bg-stone-900 text-white rounded-xl text-sm font-medium hover:bg-stone-800 disabled:opacity-50 flex items-center justify-center"
                      >
                        {isProcessingBatch ? <Loader2 className="w-4 h-4 animate-spin mr-2" /> : <Play className="w-4 h-4 mr-2" />}
                        Avvia
                      </button>
                      <button
                        onClick={clearBatch}
                        className="p-3 bg-stone-100 text-stone-600 rounded-xl hover:bg-stone-200 transition-colors"
                      >
                        <RotateCcw className="w-4 h-4" />
                      </button>
                    </div>

                    {batchItems.some(i => i.status === 'completed') && (
                      <button
                        onClick={downloadCSV}
                        className="w-full py-3 bg-emerald-600 text-white rounded-xl text-sm font-medium hover:bg-emerald-700 transition-colors flex items-center justify-center"
                      >
                        <Download className="w-4 h-4 mr-2" />
                        Scarica Risultati
                      </button>
                    )}
                  </div>
                )}
              </div>

              <div className="md:col-span-2 bg-white rounded-3xl border border-stone-200 shadow-sm overflow-hidden flex flex-col h-[600px]">
                <div className="p-4 border-b border-stone-100 bg-stone-50/50 flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4">
                  <h3 className="text-xs font-mono uppercase tracking-widest text-stone-400">Coda di Elaborazione</h3>
                  
                  <div className="flex items-center w-full sm:w-auto">
                    <div className="relative w-full sm:w-48">
                      <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 w-3.5 h-3.5 text-stone-400" />
                      <input
                        type="text"
                        value={filterLocation}
                        onChange={(e) => setFilterLocation(e.target.value)}
                        placeholder="Filtra per sede..."
                        className="w-full pl-8 pr-3 py-1.5 bg-white border border-stone-200 rounded-lg text-xs focus:outline-none focus:ring-1 focus:ring-stone-400"
                      />
                    </div>
                  </div>

                  {isProcessingBatch && (
                    <div className="flex items-center text-[10px] font-mono text-emerald-600 uppercase tracking-widest animate-pulse">
                      <Loader2 className="w-3 h-3 animate-spin mr-1.5" /> Elaborazione in corso...
                    </div>
                  )}
                </div>
                
                <div className="flex-1 overflow-y-auto p-4 space-y-2">
                  {batchItems.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-stone-400 space-y-4">
                      <Building2 className="w-12 h-12 opacity-20" />
                      <p className="text-sm font-mono uppercase tracking-widest">Nessun dato caricato</p>
                    </div>
                  ) : filteredBatchItems.length === 0 ? (
                    <div className="h-full flex flex-col items-center justify-center text-stone-400 space-y-4">
                      <Search className="w-12 h-12 opacity-20" />
                      <p className="text-sm font-mono uppercase tracking-widest">Nessun risultato per questo filtro</p>
                    </div>
                  ) : (
                    filteredBatchItems.map((item, i) => (
                      <div key={i} className={`p-3 rounded-xl border transition-all flex items-center justify-between ${
                        item.status === 'processing' ? 'bg-stone-50 border-stone-300 ring-1 ring-stone-200' :
                        item.status === 'completed' ? 'bg-emerald-50/30 border-emerald-100' :
                        item.status === 'error' ? 'bg-red-50/30 border-red-100' :
                        'bg-white border-stone-100'
                      }`}>
                        <div className="flex items-center space-x-3 overflow-hidden">
                          <div className={`w-2 h-2 rounded-full shrink-0 ${
                            item.status === 'processing' ? 'bg-stone-400 animate-pulse' :
                            item.status === 'completed' ? 'bg-emerald-500' :
                            item.status === 'error' ? 'bg-red-500' :
                            'bg-stone-200'
                          }`} />
                          <div className="flex flex-col overflow-hidden">
                            <span className="text-sm font-medium truncate">{item.query}</span>
                            {item.result?.headquarters && (
                              <span className="text-[10px] text-stone-400 truncate">{item.result.headquarters}</span>
                            )}
                          </div>
                        </div>
                        
                        <div className="flex items-center space-x-4 shrink-0">
                          {item.status === 'completed' && item.result && (
                            <div className="flex space-x-4 text-[10px] font-mono text-stone-500">
                              <span className="hidden sm:inline">IVA: {item.result.vatNumber}</span>
                              <span className="hidden sm:inline">CF: {item.result.taxCode}</span>
                            </div>
                          )}
                          {item.status === 'error' && (
                            <span className="text-[10px] font-mono text-red-500 uppercase tracking-widest">Errore</span>
                          )}
                          {item.status === 'processing' && (
                            <Loader2 className="w-4 h-4 text-stone-400 animate-spin" />
                          )}
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </div>
          </div>
        )}
      </main>

      <footer className="mt-auto py-8 text-stone-400 text-xs font-mono uppercase tracking-widest">
        &copy; {new Date().getFullYear()} &middot; Business Intelligence Tool
      </footer>
    </div>
  );
}
